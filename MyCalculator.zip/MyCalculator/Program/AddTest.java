package Program;

import static org.junit.Assert.*;

import org.junit.Test;

public class AddTest {

	@Test
	
		public void AddTest() {
			MyClass1 junit = new MyClass1();
			
			int result = junit.add(100,200);
			assertEquals(300,result);
	}

}
