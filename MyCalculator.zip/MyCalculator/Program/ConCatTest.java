package Program;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConCatTest {

	@Test
	public void ConCatTest() {
MyClass1 junit = new MyClass1();
		
		String result = junit.ConCat("Hello","World");
		assertEquals("HelloWorld",result);
	}

}
